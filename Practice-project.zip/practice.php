<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="This is a seo friendly website">
    <title>My Practice</title>

    <!-- for font-awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer">


    <!-- for web font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@300;400;600;700&display=swap" rel="stylesheet">

    <!-- for third party css -->
    <link rel="stylesheet" href="vendors/css/normalize.css">
    <!-- <link rel="stylesheet" href="vendors/css/Grid.css"> -->
    <link rel="stylesheet" href="vendors/css/4cols.css">
    <link rel="stylesheet" href="vendors/css/responsivegridsystem/css/2cols.css">
    <link rel="stylesheet" href="vendors/css/responsivegridsystem/css/col.css">

    <!-- for main css -->
    <link rel="stylesheet" href="Resources/css/style.css">
    <link rel="stylesheet" href="Resources/css/responsive.css">
</head>
<body>
    <!-- header start here -->
    <header id="home">
        <nav>
            <div class="row">
                <a href="#home"><img src="Resources/image/logo.png" alt="Cuda" class="logo"></a>
            
                <ul class="main-nav">
                    <li><a href="#home" class="active">home</a></li>
                    <li><a href="#service">service</a></li>
                    <li><a href="#work">team</a></li>
                    <li><a href="#skill">skills</a></li>
                    <li><a href="#portfolio">portfolio</a></li>
                    <li><a href="#about">about</a></li>
                    <li><a href="#contact">contact</a></li>
                </ul>
                <div class="mobile-menu">
                    <span style="color:#fff ;" onclick="openNav()">&#9776;</span>
                    <div id="myNav" class="overlay">
                        <a href="javascript:void(0)" onclick="closeNav()" class="close-btn">&times;</a>
                        <div class="overlay-content">
                        <a href="#home" onclick="closeNav()">home</a>
                        <a href="#service" onclick="closeNav()">service</a>
                        <a href="#work" onclick="closeNav()">team</a>
                        <a href="#skill" onclick="closeNav()">skills</a>
                        <a href="#portfolio" onclick="closeNav()">portfolio</a>
                        <a href="#about" onclick="closeNav()">about</a>
                        <a href="#contact" onclick="closeNav()">contact</a>
                        </div>
                    </div>
                </div>
            </div>
           
        </nav>
        <div class="row">
            <div class="here-text-box">
                <h1>Hi there! We are the new kids on the block <br> and we build awesome websites and mobile apps.</h1>
                <a href="#contact" class="btn btn-hero">work with us!</a>
            </div>
        </div>
        
    </header>
    <!-- header end here -->

    <!-- service start here -->
    <section class="service clearfix js--services-section" id="service">
        <div class="row">
            <h2>SERVICES WE PROVIDE</h2>
            <p class="little-description">We are working with both individuals and businesses from all over the globe to create awesome websites and applications.</p>
        </div>
        <div class="row">
            <div class="col span_1_of_4 box">
                <img src="Resources/image/flagicon.png" alt="flag icon" class="service-icon">
                <h3>Branding</h3>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh.</p>
            </div>
            <div class="col span_1_of_4 box">
                <img src="Resources/image/Crayon-icon.png" alt="Crayon icon" class="service-icon">
                <h3>Design</h3>
                <p>Sed ut perspiciatis unde <br> omnis iste natus error sit voluptatem  </p>
            </div>
            <div class="col span_1_of_4 box">
                <img src="Resources/image/Gear-icon.png" alt="gear icon" class="service-icon">
                <h3>development</h3>
                <p>At vero eos et accusamus et iusto odio dignissimos qui blanditiis praesentium.</p>
            </div>
            <div class="col span_1_of_4 box">
                <img src="Resources/image/rocket-icon.png" alt="rocket icon" class="service-icon">
                <h3>rocket science</h3>
                <p>Et harum quidem rerum est et expedita distinctio. Nam libero tempore.</p>
            </div>
        </div>
    </section>
    <!-- service end here -->

    <!-- work section start here  -->
    <section class="work clearfix" id="work">
        <div class="row">
            <h2>meet our beautiful team</h2>
            <p class="work-description">We are a small team of designers and developers, who help brands with big ideas.
            </p>
        </div>
        <div class="row">
            <div class="col span_1_of_4 box">
                <img src="Resources/image/man1.jpg" alt="man image" class="man-img">
                <h3>ANNE HATHAWAY</h3>
                <span class="role">CEO / Marketing Guru</span>
                <p>Lorem ipsum dolor sit amet consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.</p>
                <div class="social-icon">
                    <ul>
                        <li><a href="https://www.facebook.com" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                        <li><a href="https://www.twitter.com" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                        <li><a href="https://www.linkedin.com" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                        <li><a href="https://www.gmail.com" target="_blank"><i class="fa-solid fa-envelope"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col span_1_of_4 box">
                <img src="Resources/image/man2.jpg" alt="man image" class="man-img">
                <h3>Kate Upton</h3>
                <span class="role">Creative Director</span>
                <p>Duis aute irure dolor in in voluptate velit esse cillum dolore fugiat nulla pariatur. Excepteur sint occaecat non diam proident.</p>
                <div class="social-icon">
                    <ul>
                        <li><a href="https://www.facebook.com" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                        <li><a href="https://www.twitter.com" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                        <li><a href="https://www.linkedin.com" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                        
                    </ul>
                </div>
            </div>
            <div class="col span_1_of_4 box">
                <img src="Resources/image/man3.jpeg" alt="man image" class="man-img">
                <h3>Olivia Wilde</h3>
                <span class="role">Lead Designer</span>
                <p>Nemo enim ipsam voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem nesciunt.</p>
                <div class="social-icon">
                    <ul>
                        <li><a href="https://www.facebook.com" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                        <li><a href="https://www.twitter.com" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                        <li><a href="https://www.linkedin.com" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                        <li><a href="https://www.gmail.com" target="_blank"><i class="fa-solid fa-envelope"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col span_1_of_4 box">
                <img src="Resources/image/man4.jpg" alt="man image" class="man-img">
                <h3>Ashley Greene</h3>
                <span class="role">SEO / Developer</span>
                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                <div class="social-icon">
                    <ul>
                        <li><a href="https://www.facebook.com" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                        <li><a href="https://www.twitter.com" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                        <li><a href="https://www.linkedin.com" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                       
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- skill section start here -->
    <section class="skills clearfix" id="skill">
        <div class="row">
            <h2>we got skills!</h2>
            <p class="little-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
        </div>
        <div class="row">
            <div class="col span_1_of_4 box">
                <svg class="radial-progress web-design" data-percentage="90" viewBox="0 0 80 80">
                    <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                    <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                    <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">90%</text>
                  </svg>
                  <h3>web design</h3>
            </div>
            <div class="col span_1_of_4 box">
                <svg class="radial-progress html-css" data-percentage="75" viewBox="0 0 80 80">
                    <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                    <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                    <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">75%</text>
                  </svg>
                  <h3>html / css</h3>
            </div>
            <div class="col span_1_of_4 box">
                <svg class="radial-progress graphic-design" data-percentage="70" viewBox="0 0 80 80">
                    <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                    <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                    <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">70%</text>
                  </svg>
                  <h3>graphic design</h3>
            </div>
            <div class="col span_1_of_4 box">
                <svg class="radial-progress ui-ux" data-percentage="85" viewBox="0 0 80 80">
                    <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                    <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                    <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">85%</text>
                  </svg>
                  <h3>ui / ux</h3>
            </div>
        </div>
        
    </section>
    <!-- skill section end here -->

    <!-- portfolio section start here -->
    <section class="portfolio clearfix" id="portfolio">
        <div class="row">
            <h2>our portfolio</h2>
            <p class="little-description">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet
                consectetur, adipisci velit, sed quia non numquam</p>
        </div>
        <div class="row">
           <div class="portfolio-filter">
                <button type="button" data-filter="all">all</button>
                <button type="button" data-filter=".web">web</button>
                <button type="button" data-filter=".apps">apps</button>
                <button type="button" data-filter=".icons">icons</button>
            </div>
        </div>
        <div class="row container">
            <div class="col span_1_of_2 mix apps box">
                <img src="Resources/image/laptop1.png" alt="portfolio_1" class= "rtfolio-img">
                <h4>Isometric Perspective Mock-Up</h4>
            </div>
            <div class="col span_1_of_2 mix apps web box">
                <img src="Resources/image/laptop2.png" alt="portfolio_2" class= "rtfolio-img">
                <h4>Time Zone App UI</h4>
            </div>
            <div class="col span_1_of_2 mix icons box">
                <img src="Resources/image/laptop3.png" alt="portfolio_3" class= "rtfolio-img">
                <h4>Viro Media Players UI</h4>
            </div>
            <div class="col span_1_of_2 mix apps web icons box">
                <img src="Resources/image/laptop4.png" alt="portfolio_4" class= "rtfolio-img">
                <h4>Blog / Magazine Flat UI Kit</h4>
            </div>
        </div>
        <div class="row">
            <div>
                <a href="" class="btn btn-load-more">load more projects</a>
            </div>
        </div>
    </section>
    <!-- portfolio section end here -->  
    
    <!-- about us section start here -->
    <section class="about-us clearfix" id="about">
        <div class="row">
            <h2>what people say about us</h2>
            <p class="little-description">Our clients love us!
            </p>
        </div>
        <div class="row">
            <div class="col span_1_of_2 box">
                <div class="about-img">
                    <img  src="Resources/image/man1.jpg" alt="our client 3">
                </div>
               <div class="client-desc">
                    <p class="role">“Nullam dapibus blandit orci, viverra gravida dui lobortis eget. Maecenas fringilla urna eu nisl scelerisque.”
                    </p>
                    <h3>channel iman</h3>
                    <span>CEO of Pinterest
                    </span>
               </div>
            </div>
            <div class="col span_1_of_2 box">
                <div class="about-img">
                    <img  src="Resources/image/man2.jpg" alt="our client 3">
                </div>
                <div class="client-desc">
                    <p class="role">“Vivamus luctus urna sed urna ultricies ac tempor dui sagittis. In condimentum facilisis porta.”
                    </p>
                    <h3>adriana lima</h3>
                    <span>Founder of Instagram</span>
                </div>
            </div>
            <div class="col span_1_of_2 box">
                <div class="about-img">
                    <img  src="Resources/image/man3.jpeg" alt="our client 3">
                </div>
                <div class="client-desc">
                    <p class="role">“Vivamus luctus urna sed urna ultricies ac tempor dui sagittis. In condimentum facilisis porta.”
                    </p>
                    <h3>anne hathaway</h3>
                    <span>Lead Designer at Behance
                    </span>
                </div>
            </div>
            <div class="col span_1_of_2 box">
                <div class="about-img">
                    <img  src="Resources/image/man4.jpg" alt="our client 3">
                </div>
                <div class="client-desc">
                    <p class="role">“Phasellus non purus vel arcu tempor commodo. Fusce semper, purus vel luctus molestie, risus sem cursus neque.”
                    </p>
                    <h3>emma stone</h3>
                    <span>Co-Founder of Shazam
                    </span>
                </div>
            </div>
        </div>
    </section>
    <!-- about us section end here -->


    <!-- contact section start here -->
    <section class="contact" id="contact">
        <div class="row">
            <h2>get in touch</h2>
            <p class="little-description">1600 Pennsylvania Ave NW, Washington, DC 20500, United States of America. Tel: (202) 456-1111</p>
        </div>
        <div class="row">
            <form action="https://formspree.io/alaminislam9260@gmail.com" method="post">
                <div class="row">
                    <div class="col span_1_of_2">
                        <input type="text" name="name" id="name" placeholder="Your Name*" required> 
                    </div>
                    <div class="col span_1_of_2">
                        <input type="email" name="email" id="email" placeholder="Your Email*" required>
                    </div>
                </div>

                <div class="row">
                    <textarea name="" id="" cols="30" rows="10" placeholder="Your Message*"></textarea>
                </div>
            
                <div class="row">
                    <input class="btn btn-massage" type="submit" name="submit" id="submit" value="send message">
                </div>
            </form>
        </div>

    </section>
    <!-- contact section end here -->

    <!-- footer section start here -->
 
      <section class="footer">
        <div class="row">
            <ul>
                <li><a href="">facebook</a></li>
                <li><a href="">twitter</a></li>
                <li><a href="">google +</a></li>
                <li><a href="">linkedin</a></li>
                <li><a href="">behance</a></li>
                <li><a href="">dribbble</a></li>
                <li><a href="">GitHub</a></li>
                <li><a href="#home"><i class="fa-solid fa-arrow-up"></i></a></li>
            </ul>
       </div>
      </section>
    
    <!-- footer section end here -->

    <!-- add script -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script src="vendors/js/html5shiv.min.js"></script>
    <script src="vendors/js/jquery.waypoints.min.js"></script>
    <script src="vendors/js/respond.min.js"></script>
    <script src="vendors/js/selectivizr.js"></script>
    
    <script src="vendors/js/mixitup.min.js"></script>
    <script src="Resources/js/index.js"></script>
</body>
</html>